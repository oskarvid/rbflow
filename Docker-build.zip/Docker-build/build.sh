#echo 'Update rbFlow engine'
#rm rbFlow_Engine/rbFlow.zip
#sh -c 'cd ../../ && zip -r rbFlow.zip rbFlow'
#mv ../../rbFlow.zip rbFlow_Engine/

echo 'Build Docker Image'
TAG=`date "+%Y%m%d"`
docker build -t oskarv/rbflow:$TAG --rm=true .
